import React, { useState } from 'react';
import { X, Lock, Mail, AlertCircle, CheckCircle, RefreshCw } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { login, getCurrentUser, requestNewVerificationCode } from '../../lib/authService';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSwitchToRegister: () => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose, onSwitchToRegister }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false,
  });
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSendingVerification, setIsSendingVerification] = useState(false);

  // Get redirect path from location state if available
  const from = location.state?.from || '/dashboard';
  const verificationError = location.state?.verificationError;

  // Get saved email if available (from registration or previous login)
  const currentUser = getCurrentUser();
  
  // Pre-fill email if we have it
  React.useEffect(() => {
    if (currentUser?.email && formData.email === '') {
      setFormData(prev => ({ ...prev, email: currentUser.email }));
    }
  }, [currentUser, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);
    setIsLoading(true);

    try {
      // Call the login function from authService
      await login(formData.email, formData.password);
      
      // Success
      onClose();
      
      // Redirect to the page they were trying to access or dashboard
      navigate(from);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('Invalid email or password. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendVerification = async () => {
    const emailToUse = currentUser?.email || formData.email;
    
    if (!emailToUse) {
      setError('Please enter your email address first');
      return;
    }
    
    setIsSendingVerification(true);
    setError(null);
    setSuccessMessage(null);
    
    try {
      await requestNewVerificationCode(emailToUse);
      setSuccessMessage(`Verification email resent to ${emailToUse}. Please check your inbox and spam folder.`);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('Failed to resend verification email. Please try again.');
      }
    } finally {
      setIsSendingVerification(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div
        className="absolute inset-0 bg-black bg-opacity-80 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative w-full max-w-md bg-[rgba(255,255,255,0.1)] backdrop-blur-[10px] border border-[rgba(254,2,161,0.3)] rounded-xl p-6 animate-fade-in">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-white/60 hover:text-[#FE02A1] transition-colors duration-200"
        >
          <X size={20} />
        </button>

        {/* Title */}
        <h2 className="text-2xl font-['Exo_2'] font-bold text-white mb-6 [text-shadow:0_0_15px_#FE02A1]">
          Welcome Back
        </h2>

        {/* Verification Error Message */}
        {verificationError && (
          <div className="flex items-center gap-2 text-sm text-yellow-400 bg-yellow-400/10 p-3 rounded-lg mb-4">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <div>
              <p className="font-semibold">Your account needs verification</p>
              <p className="text-xs mt-1">Please check your email for a verification link or request a new one below.</p>
              <button
                type="button"
                onClick={handleResendVerification}
                disabled={isSendingVerification}
                className="mt-2 text-xs flex items-center gap-1 text-[#FE02A1] hover:underline"
              >
                {isSendingVerification ? (
                  <>
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    Sending verification email...
                  </>
                ) : (
                  <>Resend verification email</>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Success Message */}
        {successMessage && (
          <div className="flex items-center gap-2 text-sm text-green-400 bg-green-400/10 p-3 rounded-lg mb-4">
            <CheckCircle className="w-4 h-4" />
            {successMessage}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email Field */}
          <div>
            <label className="block text-sm font-medium text-white mb-1">
              Email Address
            </label>
            <div className="relative">
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full pl-10 pr-4 py-2 bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] rounded-lg text-white placeholder-white/50 focus:border-[#FE02A1] transition-colors duration-300"
                placeholder="Enter your email"
                required
              />
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
            </div>
          </div>

          {/* Password Field */}
          <div>
            <label className="block text-sm font-medium text-white mb-1">
              Password
            </label>
            <div className="relative">
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full pl-10 pr-4 py-2 bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.1)] rounded-lg text-white placeholder-white/50 focus:border-[#FE02A1] transition-colors duration-300"
                placeholder="Enter your password"
                required
              />
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
            </div>
          </div>

          {/* Remember Me & Forgot Password */}
          <div className="flex items-center justify-between">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={formData.rememberMe}
                onChange={(e) => setFormData({ ...formData, rememberMe: e.target.checked })}
                className="w-4 h-4 rounded border-[rgba(255,255,255,0.1)] bg-[rgba(255,255,255,0.05)] text-[#FE02A1] focus:ring-[#FE02A1]"
              />
              <span className="ml-2 text-sm text-white">Remember me</span>
            </label>
            <button
              type="button"
              className="text-sm text-[#FE02A1] hover:text-white transition-colors duration-300"
            >
              Forgot Password?
            </button>
          </div>

          {/* Error Message */}
          {error && (
            <div className="flex items-center gap-2 text-sm text-red-400 bg-red-400/10 p-2 rounded-lg">
              <AlertCircle className="w-4 h-4" />
              {error}
            </div>
          )}

          {/* Verification Link */}
          {!verificationError && (
            <div className="text-center">
              <button
                type="button"
                onClick={handleResendVerification}
                disabled={isSendingVerification}
                className="text-xs text-[#FE02A1] hover:underline flex items-center gap-1 mx-auto"
              >
                {isSendingVerification ? (
                  <>
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    Sending verification email...
                  </>
                ) : (
                  <>Need to verify your account? Send verification email</>
                )}
              </button>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full px-6 py-2 bg-[#FE02A1] rounded-lg text-white hover:scale-105 hover:shadow-[0_0_20px_#FE02A1] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
          >
            {isLoading ? 'Logging in...' : 'Log In'}
          </button>
          
          {/* Switch to Register */}
          <div className="text-center mt-4">
            <p className="text-white/60 text-sm">
              Don't have an account?{' '}
              <button
                type="button"
                onClick={onSwitchToRegister}
                className="text-[#FE02A1] hover:underline"
              >
                Create Account
              </button>
            </p>
          </div>

          {/* Privacy Notice */}
          <div className="text-xs text-white/60 text-center">
            By logging in, you agree to our{' '}
            <a href="#" className="text-[#FE02A1] hover:underline">
              Terms of Service
            </a>{' '}
            and{' '}
            <a href="#" className="text-[#FE02A1] hover:underline">
              Privacy Policy
            </a>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginModal;