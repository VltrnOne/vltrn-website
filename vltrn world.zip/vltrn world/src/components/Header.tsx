import React, { useState, useEffect } from 'react';
import { Menu, X, LogOut, Database } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import clsx from 'clsx';
import ClientIntakeForm from './forms/ClientIntakeForm';
import LoginModal from './auth/LoginModal';
import RegisterModal from './auth/RegisterModal';
import { isAuthenticated, logout, getCurrentUser } from '../lib/authService';
import ApiAccessButton from './ApiAccessButton';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [verificationError, setVerificationError] = useState(false);
  const [userLoggedIn, setUserLoggedIn] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  // Check authentication status when component mounts and location changes
  useEffect(() => {
    setUserLoggedIn(isAuthenticated());
    
    // Check if we should show login modal from location state
    if (location.state?.showLogin) {
      setIsLoginOpen(true);
      if (location.state.verificationError) {
        setVerificationError(true);
      } else {
        setVerificationError(false);
      }
      // Clear the state to prevent modal showing on page refresh
      window.history.replaceState({}, document.title);
    } else if (location.state?.showRegister) {
      setIsRegisterOpen(true);
      // Clear the state to prevent modal showing on page refresh
      window.history.replaceState({}, document.title);
    }
  }, [location]);

  const navItems = [
    { name: 'Community', path: '/community' },
    { name: 'Partners', path: '/partners' },
  ];

  const managementItems = [
    { name: 'Client Intakes', path: '/client-intakes' },
    { name: 'Projects', path: '/projects' },
    { name: 'Tasks', path: '/tasks' },
    { name: 'Resources', path: '/resources' },
  ];

  const isActive = (path: string) => location.pathname === path;

  const handleLogout = () => {
    logout();
    setUserLoggedIn(false);
    // Redirect to home page after logout
    window.location.href = '/';
  };
  
  const handleStartNowClick = () => {
    const currentUser = getCurrentUser();
    
    if (!userLoggedIn) {
      setIsLoginOpen(true);
    } else if (currentUser && !currentUser.isVerified) {
      // User is logged in but not verified
      setVerificationError(true);
      setIsLoginOpen(true);
    } else {
      setIsFormOpen(true);
    }
  };
  
  const switchToRegister = () => {
    setIsLoginOpen(false);
    setIsRegisterOpen(true);
  };
  
  const switchToLogin = () => {
    setIsRegisterOpen(false);
    setIsLoginOpen(true);
  };

  return (
    <>
      <header className="fixed w-full z-[1000] px-4 py-2">
        <div className="max-w-7xl mx-auto">
          <nav className="relative flex items-center justify-between h-16 bg-[rgba(255,255,255,0.1)] backdrop-blur-[10px] border border-[rgba(254,2,161,0.3)] rounded-lg shadow-[0_0_20px_rgba(254,2,161,0.2)]">
            {/* Logo */}
            <div className="px-4">
              <Link to="/" className="text-[#FE02A1] font-['Exo_2'] text-2xl font-bold">
                VLTRN
              </Link>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center justify-end flex-1">
              {/* Public Navigation */}
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={clsx(
                    'px-6 py-2 text-white transition-all duration-300 hover:-translate-y-0.5 hover:text-[#FE02A1] hover:shadow-[0_0_10px_#FE02A1]',
                    isActive(item.path) && 'text-[#FE02A1] shadow-[0_0_10px_#FE02A1]'
                  )}
                >
                  {item.name}
                </Link>
              ))}
              
              {/* Management Navigation (only for logged in users) */}
              {userLoggedIn && managementItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={clsx(
                    'px-6 py-2 text-white transition-all duration-300 hover:-translate-y-0.5 hover:text-[#FE02A1] hover:shadow-[0_0_10px_#FE02A1]',
                    isActive(item.path) && 'text-[#FE02A1] shadow-[0_0_10px_#FE02A1]'
                  )}
                >
                  {item.name}
                </Link>
              ))}
            </div>

            {/* Desktop Buttons */}
            <div className="hidden md:flex items-center gap-4 px-4">
              {/* Hidden API Access Button */}
              <ApiAccessButton />
              
              {userLoggedIn ? (
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-2 px-4 py-2 bg-[#FE02A1] rounded-lg text-white hover:scale-105 hover:shadow-[0_0_20px_#FE02A1] transition-all duration-300"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </button>
              ) : (
                <button
                  onClick={() => setIsLoginOpen(true)}
                  className="px-4 py-2 bg-[#FE02A1] rounded-lg text-white hover:scale-105 hover:shadow-[0_0_20px_#FE02A1] transition-all duration-300"
                >
                  Login
                </button>
              )}
              <button
                onClick={handleStartNowClick}
                className="px-6 py-2.5 bg-[#FE02A1] rounded-lg text-white font-semibold hover:scale-105 hover:shadow-[0_0_20px_#FE02A1] transition-all duration-300"
              >
                Start Now
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden px-4 flex items-center gap-2">
              {/* Hidden API Access Button for mobile */}
              <ApiAccessButton />
              
              <button
                className="text-white hover:text-[#FE02A1] transition-colors duration-300"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </nav>

          {/* Mobile Navigation */}
          <div
            className={`md:hidden absolute top-[calc(100%+0.5rem)] left-0 right-0 bg-[rgba(255,255,255,0.1)] backdrop-blur-[10px] border border-[rgba(254,2,161,0.3)] rounded-lg shadow-[0_0_20px_rgba(254,2,161,0.2)] transform transition-all duration-300 ease-in-out ${
              isMenuOpen ? 'translate-y-0 opacity-100' : '-translate-y-4 opacity-0 pointer-events-none'
            }`}
          >
            <div className="flex flex-col p-4 space-y-4">
              {/* Public Navigation */}
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={clsx(
                    'text-white hover:text-[#FE02A1] hover:translate-x-2 transition-all duration-300 hover:shadow-[0_0_10px_#FE02A1] px-4 py-2',
                    isActive(item.path) && 'text-[#FE02A1] shadow-[0_0_10px_#FE02A1]'
                  )}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
              
              {/* Management Navigation (only for logged in users) */}
              {userLoggedIn && (
                <>
                  <div className="border-t border-[rgba(254,2,161,0.3)] pt-4 mt-2">
                    <div className="text-white/60 text-sm px-4 mb-2">Management</div>
                    {managementItems.map((item) => (
                      <Link
                        key={item.name}
                        to={item.path}
                        className={clsx(
                          'text-white hover:text-[#FE02A1] hover:translate-x-2 transition-all duration-300 hover:shadow-[0_0_10px_#FE02A1] px-4 py-2',
                          isActive(item.path) && 'text-[#FE02A1] shadow-[0_0_10px_#FE02A1]'
                        )}
                        onClick={() => setIsMenuOpen(false)}
                      >
                        {item.name}
                      </Link>
                    ))}
                  </div>
                </>
              )}
              
              <div className="flex flex-col gap-3 pt-4 border-t border-[rgba(254,2,161,0.3)]">
                {userLoggedIn ? (
                  <button
                    onClick={() => {
                      handleLogout();
                      setIsMenuOpen(false);
                    }}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-[#FE02A1] rounded-lg text-white hover:scale-105 hover:shadow-[0_0_20px_#FE02A1] transition-all duration-300"
                  >
                    <LogOut className="w-4 h-4" />
                    Logout
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      setIsLoginOpen(true);
                      setIsMenuOpen(false);
                    }}
                    className="w-full px-4 py-2 bg-[#FE02A1] rounded-lg text-white hover:scale-105 hover:shadow-[0_0_20px_#FE02A1] transition-all duration-300"
                  >
                    Login
                  </button>
                )}
                <button
                  onClick={() => {
                    handleStartNowClick();
                    setIsMenuOpen(false);
                  }}
                  className="w-full px-6 py-2.5 bg-[#FE02A1] rounded-lg text-white font-semibold hover:scale-105 hover:shadow-[0_0_20px_#FE02A1] transition-all duration-300"
                >
                  Start Now
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Modals */}
      <ClientIntakeForm isOpen={isFormOpen} onClose={() => setIsFormOpen(false)} />
      <LoginModal 
        isOpen={isLoginOpen} 
        onClose={() => {
          setIsLoginOpen(false);
          setVerificationError(false);
        }} 
        onSwitchToRegister={switchToRegister}
      />
      <RegisterModal 
        isOpen={isRegisterOpen} 
        onClose={() => setIsRegisterOpen(false)} 
        onSwitchToLogin={switchToLogin}
      />
    </>
  );
};

export default Header;